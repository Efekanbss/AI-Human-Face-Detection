import torch

print("CUDA kullanılabilir mi? :", torch.cuda.is_available())
print("CUDA versiyonu:", torch.version.cuda)
print("PyTorch versiyonu:", torch.__version__)

if torch.cuda.is_available():
    print("Kullanılabilir GPU:", torch.cuda.get_device_name(0))
    print("Toplam GPU sayısı:", torch.cuda.device_count())
    print("Aktif GPU ID:", torch.cuda.current_device())
else:
    print("GPU bulunamadı, işlemler CPU üzerinden yapılacak.")
