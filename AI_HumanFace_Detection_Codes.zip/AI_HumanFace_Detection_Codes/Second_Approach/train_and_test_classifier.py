import numpy as np
import time
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

# --- STEP 1: LOAD DATA ---

train_X = np.load("train_X.npy")
train_y = np.load("train_y.npy")
val_X = np.load("val_X.npy")
val_y = np.load("val_y.npy")
test_X = np.load("test_X.npy")
test_y = np.load("test_y.npy")

# Combine train and validation sets for cross-validation
X = np.concatenate([train_X, val_X], axis=0)
y = np.concatenate([train_y, val_y], axis=0)

print(f"Data Shapes ➤ Train+Val: {X.shape}, Test: {test_X.shape}")

# --- STEP 2: MODEL LIST ---

models = {
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=1000, C=0.5),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "MLP": MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=500, random_state=42),
    "XGBoost": XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42),
    "LightGBM": LGBMClassifier(random_state=42),
    "CatBoost": CatBoostClassifier(verbose=0, random_state=42)
}

# --- STEP 3: MODEL TRAINING, CROSS-VALIDATION, AND TEST PERFORMANCE ---

for name, model in models.items():
    print(f"\n{name} 3-Fold Cross Validation starting...")
    start_time = time.time()

    acc_list, prec_list, rec_list, f1_list = [], [], [], []
    skf = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)

    for fold, (train_idx, val_idx) in enumerate(skf.split(X, y), 1):
        X_train, X_val = X[train_idx], X[val_idx]
        y_train, y_val = y[train_idx], y[val_idx]

        model.fit(X_train, y_train)
        preds = model.predict(X_val)

        acc_list.append(accuracy_score(y_val, preds))
        prec_list.append(precision_score(y_val, preds))
        rec_list.append(recall_score(y_val, preds))
        f1_list.append(f1_score(y_val, preds))

        print(f"  Fold {fold} - Acc: {acc_list[-1]:.4f}, Prec: {prec_list[-1]:.4f}, Recall: {rec_list[-1]:.4f}, F1: {f1_list[-1]:.4f}")

    print(f"\nAverage CV Results (3 Fold) ➤ {name}")
    print(f"  Accuracy:  {np.mean(acc_list):.4f}")
    print(f"  Precision: {np.mean(prec_list):.4f}")
    print(f"  Recall:    {np.mean(rec_list):.4f}")
    print(f"  F1-score:  {np.mean(f1_list):.4f}")

    # Test set performance
    test_preds = model.predict(test_X)
    acc = accuracy_score(test_y, test_preds)
    prec = precision_score(test_y, test_preds)
    rec = recall_score(test_y, test_preds)
    f1 = f1_score(test_y, test_preds)

    print(f"\nTest Set Results ➤ {name}")
    print(f"  Accuracy:  {acc:.4f}")
    print(f"  Precision: {prec:.4f}")
    print(f"  Recall:    {rec:.4f}")
    print(f"  F1-score:  {f1:.4f}")
    print("  Classification Report:")
    print(classification_report(test_y, test_preds, target_names=["fake", "real"]))
    print("  Confusion Matrix:")
    print(confusion_matrix(test_y, test_preds))

    elapsed = time.time() - start_time
    print(f"Model runtime: {elapsed:.2f} seconds")
