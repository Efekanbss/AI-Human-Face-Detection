import os
import time
import numpy as np
from tqdm import tqdm
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.base import clone
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
from catboost import CatBoostClassifier

# Activate only the desired models here
SELECTED_MODELS = [
    # "SVM (RBF)",
    # "Random Forest",
    # "Decision Tree",
    # "Logistic Regression",
    # "KNN",
    # "MLP",
    # "XGBoost",
    # "LightGBM",
    # "CatBoost"
    
]

# File paths
X_path = "features/X_features.npy"
y_path = "features/y_labels.npy"

# Check if files exist
if not os.path.exists(X_path) or not os.path.exists(y_path):
    print("Feature files not found. Please run main.py first.")
    exit(1)

# Load features
X = np.load(X_path)
y = np.load(y_path)

# Define all available models
all_models = {
    "Decision Tree": DecisionTreeClassifier(random_state=42),
    "Random Forest": RandomForestClassifier(n_estimators=200, random_state=42),
    "Logistic Regression": LogisticRegression(max_iter=1000, C=0.5),
    "KNN": KNeighborsClassifier(n_neighbors=5),
    "MLP": MLPClassifier(hidden_layer_sizes=(100, 50), max_iter=500, random_state=42),
    "XGBoost": XGBClassifier(use_label_encoder=False, eval_metric='logloss', random_state=42),
    "LightGBM": LGBMClassifier(random_state=42),
    "CatBoost": CatBoostClassifier(verbose=0, random_state=42),
}

# Filter selected models
models = {}
for name in SELECTED_MODELS:
    if name in all_models:
        models[name] = all_models[name]
    else:
        print(f"Warning: '{name}' is not a valid model and will be skipped.")

if not models:
    print("No valid models selected. Please check SELECTED_MODELS list.")
    exit(1)

# Stratified 3-Fold Cross-Validation
kfold = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
results = {}

print("\nRunning selected models...\n")
start_time = time.time()

# Evaluate each selected model
for name, base_model in models.items():
    print(f"\nModel: {name}")
    fold_accuracies = []
    all_y_true = []
    all_y_pred = []

    for train_index, test_index in tqdm(kfold.split(X, y), total=kfold.get_n_splits(),
                                        desc=f"{name[:15]:<15}"):
        X_train, X_test = X[train_index], X[test_index]
        y_train, y_test = y[train_index], y[test_index]

        model = clone(base_model)
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)

        fold_accuracies.append(accuracy_score(y_test, y_pred))
        all_y_true.extend(y_test)
        all_y_pred.extend(y_pred)

    avg_acc = np.mean(fold_accuracies)
    cm = confusion_matrix(all_y_true, all_y_pred)
    report = classification_report(all_y_true, all_y_pred, output_dict=False)

    results[name] = {
        "avg_accuracy": avg_acc,
        "confusion_matrix": cm,
        "classification_report": report
    }

end_time = time.time()
total_time = end_time - start_time

# Print final results
print("\nFINAL EVALUATION REPORT\n" + "=" * 35)
for name, metrics in results.items():
    print(f"\nModel: {name}")
    print(f"Average Accuracy: {metrics['avg_accuracy']:.4f}")
    print(f"Confusion Matrix:\n{metrics['confusion_matrix']}")
    print(f"Classification Report:\n{metrics['classification_report']}")

print(f"Total time: {total_time:.2f} seconds")
