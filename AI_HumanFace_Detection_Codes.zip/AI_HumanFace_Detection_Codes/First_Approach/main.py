import time
import os
import numpy as np
from feature_extraction_pipeline import process_dataset
from sklearn.preprocessing import StandardScaler

def save_features(X, y, output_dir="features"):
    os.makedirs(output_dir, exist_ok=True)
    np.save(os.path.join(output_dir, "X_features.npy"), X)
    np.save(os.path.join(output_dir, "y_labels.npy"), y)
    print("Feature files have been saved.")

def main():
    start_time = time.time()

    ai_dir = os.path.join("data", "ai_generated")
    real_dir = os.path.join("data", "real_images")

    if not os.path.exists(ai_dir) or not os.path.exists(real_dir):
        print(f"Missing data directories:\n - {ai_dir}\n - {real_dir}")
        return

    X_ai, y_ai = process_dataset(ai_dir, label=1)
    X_real, y_real = process_dataset(real_dir, label=0)

    if len(X_ai) == 0 or len(X_real) == 0:
        print("Insufficient data. Please check the folders.")
        return

    X = np.vstack((X_ai, X_real))
    y = np.concatenate((y_ai, y_real))

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    save_features(X_scaled, y)

    print(f"Total number of samples: {X.shape[0]}")
    print(f"Feature vector length: {X.shape[1]}")

    end_time = time.time()
    duration = end_time - start_time
    print(f"Processing completed. Duration: {duration:.2f} seconds ({duration / 60:.2f} minutes)")

if __name__ == "__main__":
    main()
