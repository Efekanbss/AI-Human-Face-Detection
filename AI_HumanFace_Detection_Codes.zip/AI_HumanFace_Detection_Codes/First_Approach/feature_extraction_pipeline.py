import cv2
import numpy as np
import os
from skimage.feature import local_binary_pattern, hog
from skimage.measure import shannon_entropy
from tqdm import tqdm
import pywt

IMAGE_SIZE = (256, 256)
LBP_P = 8
LBP_R = 1

def extract_color_histogram(image, bins=(8, 8, 8)):
    image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    hist = cv2.calcHist([image_rgb], [0, 1, 2], None, bins, [0, 256, 0, 256, 0, 256])
    hist = cv2.normalize(hist, hist).flatten()
    return hist

def extract_grayscale_stats(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    mean = np.mean(gray)
    std = np.std(gray)
    return np.array([mean, std])

def extract_edge_density(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if gray.dtype != np.uint8:
        gray = (gray * 255).astype(np.uint8)
    edges = cv2.Canny(gray, 100, 200)
    density = np.sum(edges) / edges.size
    return np.array([density])

def extract_lbp_hist(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    if gray.dtype != np.uint8:
        gray = (gray * 255).astype(np.uint8)
    lbp = local_binary_pattern(gray, P=LBP_P, R=LBP_R, method='uniform')
    hist, _ = np.histogram(lbp.ravel(), bins=np.arange(0, LBP_P + 3), range=(0, LBP_P + 2))
    hist = hist.astype("float")
    hist /= (hist.sum() + 1e-6)
    return hist

def extract_hog_features(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    features, _ = hog(gray, orientations=6, pixels_per_cell=(16, 16),
                      cells_per_block=(2, 2), visualize=True, block_norm='L2-Hys')
    return features

def extract_gabor_features(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    responses = []
    for theta in (0, np.pi/4, np.pi/2, 3*np.pi/4):
        kernel = cv2.getGaborKernel((21, 21), 4.0, theta, 10.0, 0.5, 0)
        fimg = cv2.filter2D(gray, cv2.CV_8UC3, kernel)
        responses.append(fimg.mean())
    return np.array(responses)

def extract_wavelet_features(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    coeffs2 = pywt.dwt2(gray, 'haar')
    LL, (LH, HL, HH) = coeffs2
    features = [
        np.mean(LL), np.std(LL),
        np.mean(LH), np.std(LH),
        np.mean(HL), np.std(HL),
        np.mean(HH), np.std(HH)
    ]
    return np.array(features)

def extract_image_moments(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    moments = cv2.moments(gray)
    return np.array([moments['mu20'], moments['mu02'], moments['mu11']])

def extract_entropy(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    ent = shannon_entropy(gray)
    return np.array([ent])

def extract_features(image):
    if len(image.shape) == 3 and image.shape[2] == 4:
        image = cv2.cvtColor(image, cv2.COLOR_BGRA2BGR)

    if len(image.shape) != 3 or image.shape[2] not in [3, 4]:
        raise ValueError(f"Invalid image shape: {image.shape}")

    if image.shape[0] < 10 or image.shape[1] < 10:
        raise ValueError(f"Image too small: {image.shape}")

    resized = cv2.resize(image, IMAGE_SIZE)
    resized = resized.astype('float32') / 255.0

    features = np.concatenate([
        extract_color_histogram(resized),
        extract_grayscale_stats(resized),
        extract_edge_density(resized),
        extract_lbp_hist(resized),
        extract_hog_features(resized),
        extract_gabor_features(resized),
        extract_wavelet_features(resized),
        extract_image_moments(resized),
        extract_entropy(resized)
    ])
    return features

def process_dataset(image_dir, label):
    X = []
    y = []
    print(f"Processing: {image_dir}")
    for filename in tqdm(os.listdir(image_dir)):
        path = os.path.join(image_dir, filename)
        image = cv2.imread(path)

        if image is None:
            print(f"Skipping unreadable image: {filename}")
            continue

        try:
            feats = extract_features(image)
            X.append(feats)
            y.append(label)
        except Exception as e:
            print(f"Error in {filename}: {e}")
            continue

    return np.array(X), np.array(y)
